﻿namespace Model
{
    public class Cliente
    {
        public int Id { get; set; }
        public string RazaoSocial { get; set; }
    }
}
