﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VSBS.Barcode
{
    using Barcode;
    using System.IO;
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnGerar_Click(object sender, EventArgs e)
        {
            var ws = new BarCode();
            ws.Timeout = (60 * 1000) * 1;

            var bcd = new BarCodeData();
            bcd.BarCodeImageFormat = ImageFormats.PNG;
            bcd.barcodeOption = BarcodeOption.Both;
            bcd.barcodeType = BarcodeType.CodeEAN13;
            bcd.FontSize = 13;
            bcd.Left = 50;
            bcd.Top = 0;
            bcd.Width = 900;
            bcd.Height = 150;
            bcd.showTextPosition = ShowTextPosition.BottomCenter;

            var resposta = ws.GenerateBarCode(bcd, edCodigo.Text);

            using (var stream = new MemoryStream(resposta, 0, resposta.Length))
            {
                pictureBox1.Image = Image.FromStream(stream);
            }
        }
    }
}
